
        <div id="conR">
            <div class="submenu">
            <h3>事業内容</h3>
                <h4>ネット事業</h4>
                <ul>
                    <li><a href="<?php bloginfo('url'); ?>/service#s1">ホームページ制作</a></li>
                    <li><a href="<?php bloginfo('url'); ?>/service#s2">広告代理</a></li>

                </ul>
         
            </div><!-- /.bnrR -->
        </div><!-- /.conR -->
    