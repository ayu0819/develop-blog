<div class="main">
		<div class="card-img-top">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'full' ); ?>
			</a>
    </div><!-- .post-thumbnail -->
    <div class="main__textArea">
                <h3><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
                <p><?php echo mb_substr(strip_tags($post-> post_content),0,200).'...'; ?></p>
                <p><small><?php the_time('Y年m月d日'); ?></small></p>
                <p><span class="badge-padding badge badge-info tab tag_<?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->slug; } ?>"><?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?></span></p>
              </div>
              </div>