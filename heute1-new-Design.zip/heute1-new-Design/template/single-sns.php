<div class="sns">
 <h2>フォローする</h2>
 <div class="d-flex justify-content-left">
                  <a class="nav-link" href="#"><i class="fab fa-facebook-f article__facebook"></i></a>
                  <a class="nav-link" href="#"><i class="fab fa-google-plus-g article__google"></i></a>
                  <a class="nav-link" href="#"><i class="fab fa-pinterest-p article__pinterest"></i></a>
                  <a class="nav-link" href="#"><i class="fab fa-twitter article__twitter"></i></a>
                  <a class="nav-link" href="#"><i class="fab fa-linkedin-in article__linkdin"></i></a>
</div>
</div>