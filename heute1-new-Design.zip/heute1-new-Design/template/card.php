<div class="col">
 <div class="card">
		<div class="card-img-top">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'full' ); ?>
			</a>
    </div><!-- .post-thumbnail -->
    <div class="card-body">
           <h5><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h5>
           <p class="card-text"><small><?php the_time('Y年m月d日'); ?></small></p>
           <p><span class="badge badge-info tab tag_<?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->slug; } ?>"><?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?></span></p>        
    </div>
          </div>
         </div>