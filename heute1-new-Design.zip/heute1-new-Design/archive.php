<?php get_header(); ?>
    <div class="contents">
    <div class="container">
    <div class="row row-cols-1 row-cols-md-2 g-4">
  <?php if (in_category(array('4'))) {?>
    <!-- other -->
    <?php
$infoPosts = get_posts('numberposts=6&category=4');
foreach($infoPosts as $post): 
?>

<?php get_template_part( 'template/card' ); ?>


<?php endforeach; ?>
<!-- development -->
<?php } elseif(in_category(array('5'))){ ?>
<?php
$infoPosts = get_posts('numberposts=6&category=5');
foreach($infoPosts as $post): 
?>
<?php get_template_part( 'template/card' ); ?>
<?php endforeach; ?>
<!-- web-production -->
<?php } elseif(in_category(array('3'))){ ?>
 <?php
$infoPosts = get_posts('numberposts=6&category=3');
foreach($infoPosts as $post): 
?>
<?php get_template_part( 'template/card' ); ?>
<?php endforeach; ?>
<!-- inspiration -->
<?php } elseif(in_category(array('7'))){ ?>
 <?php
$infoPosts = get_posts('numberposts=6&category=7');
foreach($infoPosts as $post): 
?>
<?php get_template_part( 'template/card' ); ?>
<?php endforeach; ?>
<!-- design -->
<?php } elseif(in_category(array('11'))){ ?>
 <?php
$infoPosts = get_posts('numberposts=6&category=11');
foreach($infoPosts as $post): 
?>
<?php get_template_part( 'template/card' ); ?>
<?php endforeach; ?>
<!-- new -->
<?php } elseif(in_category(array('6'))){ ?>
 <?php
$infoPosts = get_posts('numberposts=6&category=6');
foreach($infoPosts as $post): 
?>
<?php get_template_part( 'template/card' ); ?>
<?php endforeach; ?>
<!-- e-commerce -->
<?php } elseif(in_category(array('4'))){ ?>
<?php
$infoPosts = get_posts('numberposts=6&category=4');
foreach($infoPosts as $post): 
?>
<?php get_template_part( 'template/card' ); ?>
<?php endforeach; ?>
<?php }?>
</div>
     <div class="text-center mt-5">
     <?php wp_pagenavi(); ?>
     </div>
     </div>
     </div>
    <?php get_footer(); ?>